import boto3
from decimalencoder import DecimalEncoder
import json
from boto3.dynamodb.conditions import Key, Attr

dynamodb = boto3.resource('dynamodb', 'eu-west-1')

def single(event, context):
    table = dynamodb.Table("img-posts")
    key = event['queryStringParameters']['key']

    response = table.query(KeyConditionExpression=Key('key').eq(key))
    
    response = {
        "statusCode": 200,
        "body": json.dumps(response['Items'][0], cls=DecimalEncoder),
        'headers': {
            'Access-Control-Allow-Origin': '*'
        },
    }

    return response